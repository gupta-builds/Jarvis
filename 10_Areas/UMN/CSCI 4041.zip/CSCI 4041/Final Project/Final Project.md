---
type: class
input_kind: project
status: seed
created: 2026-04-27
updated:
area:
tags:
  - "#class"
next:
---
# Maze Way
Done by 4 group members.
## Overview
- I am going to coding part: Implementation
- 1. **Implementation of your Graph Algorithms**
    - Implement required methods for your final project option (see the resource page for specific instructions).
    - Be certain that your implementation satisfies the qualitative requirements of the final project option.
    - Your implementation should roughly match the design used in part 1 and the template examples I gave for chapter 20-24.
    - You will lose points if you do not use the PrintGraph method or various other tools I have created to visualize your work.
    - **You must give a citation(s) for the sources (websites, books, articles, etc.) you used to write / design your implementation.**
## Plan
- [ ] Break down tasks
- [ ] Solve core
- [ ] Writeup/tests
- [ ] Submit
## Work log
- We are doing the Maze Generation and Solving
## Concepts used
- [[Concept - ...]]
- [[Concept - ...]]
## Post-submit reflection
- What failed first?
- What pattern repeats?