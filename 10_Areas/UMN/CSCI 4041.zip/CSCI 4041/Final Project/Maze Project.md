---
type: class
input_kind: project
status: sprout
created: 2026-04-27
updated: 2026-04-27
area:
  - "[[CSCI 4041 Board]]"
  - "[[DSA]]"
  - "[[Introduction to Algorithms]]"
tags:
  - "#class"
  - "#Project"
related:
  - "[[10_UMN/CSCI 4041/Final Project|Final Project]]"
  - "[[10_UMN/CSCI 4041/Week - 11|Week - 11]]"
  - "[[10_UMN/CSCI 4041/Week - 12|Week - 12]]"
  - "[[10_UMN/CSCI 4041/Textbook/Chapter - 20|Chapter - 20]]"
---
# Maze Project
## Overview
This was the user's chosen final project option. The project implements maze generation and solving using graph traversal algorithms. A maze is modeled as a grid graph where cells are vertices and open passages are edges. Generation creates a spanning tree of the grid (guaranteeing exactly one path between any two cells), and solving finds a path from start to finish using BFS or DFS.
## Source Files
- `Final Project/Maze/Ch20(Graphs-CodeBase)-MAZE.ipynb` — maze implementation using the course graph code base
- `Final Project/Maze/Maze-Template.ipynb` — project template with scaffolding
## Reference Papers
- `An_Algorithm_for_Path_Connections_and_Its_Applications-1961.pdf` — Lee's algorithm for path connections (1961)
- `Fast_Maze_Router-Soukup1978.pdf` — Soukup's fast maze routing algorithm (1978)
- `Networks - Winter 1977 - Hadlock - A shortest path algorithm for grid graphs.pdf` — Hadlock's shortest path on grids
- `Presentation_of_a_MazeSolving_MachineTransactions_8th_Cybernetics_Conference_Josiah_Macy_Jr._Foundation_1952..pdf` — early maze-solving machine (1952)
## Key Algorithms and Data Structures
- **Grid graph representation**: 2D grid where each cell is a vertex and edges connect adjacent open cells
- **BFS maze solving**: finds the shortest path (fewest cells) from start to finish in an unweighted grid
- **DFS maze solving**: finds a path (not necessarily shortest) by exploring as deep as possible before backtracking
- **Maze generation via spanning tree**: remove walls to create a random spanning tree of the grid, ensuring exactly one path between any two cells
- **Adjacency-list graph**: the course graph code base from [[10_UMN/CSCI 4041/Week - 11|Week - 11]] and [[10_UMN/CSCI 4041/Week - 12|Week - 12]] powers the implementation
## Concept Links
- [[10_UMN/CSCI 4041/Concepts/Graphs/Graph Algorithms|Graph Algorithms]] — BFS, DFS, graph representations
- [[10_UMN/CSCI 4041/Week - 11|Week - 11]] — BFS and DFS introduction
- [[10_UMN/CSCI 4041/Week - 12|Week - 12]] — topological sort, connected components, graph code base
- [[10_UMN/CSCI 4041/Textbook/Chapter - 20|Chapter - 20]] — graph representations, BFS, DFS
- [[10_UMN/CSCI 4041/Textbook/Chapter - 21|Chapter - 21]] — minimum spanning trees (related to maze generation)
## Complexity
| Algorithm | Time | Space |
|---|---|---|
| BFS solve | $O(V + E)$ | $O(V)$ |
| DFS solve | $O(V + E)$ | $O(V)$ |
| Maze generation | $O(V + E)$ | $O(V)$ |

For an $n \times m$ grid: $V = nm$, $E = O(nm)$. Both generation and solving are linear in the grid size.