---
name: build-tailored-resume
description: Build a one-page, ATS-safe .docx resume for Anant Gupta from the Main Resume evidence bank, tailored to a specific job description. Use whenever asked to create, alter, tailor, or update a resume for a role or company.
---

# Build Tailored Resume (.docx)

## What this skill is for

Anant maintains one authoritative resume — the **Main Resume** (bullet bank at
`20_Progress/Internship/Resumes/Main Resume.md` in the Jarvis vault, evidence-tagged
`#evidence/user-confirmed-YYYY-MM-DD`). Every resume sent to an employer is an
**altered** copy of that bank: same template, same rules, different selection of
already-confirmed content. This skill produces exactly that — one `.docx` per
invocation — and nothing else. It does not invent content, does not touch the
visual template, and does not ship a resume it hasn't verified is one page.

This skill was built from a full ATS/recruiter audit and a fact-by-fact rebuild
of the Main Resume done in a separate session (2026-08-29/30). The rules below
are the direct output of that process, not generic advice — follow them exactly.

## Non-negotiable rules — read before doing anything else

1. **Evidence-only content.** Every fact on the output resume must trace to a
   line in `Main Resume.md` tagged `#evidence/user-confirmed-...`, or to an
   explicit answer Anant just gave you in the current conversation. Never
   infer, estimate, embellish, add a metric, upgrade a verb ("contributed" →
   "led"), or resolve an ambiguity in the resume's favor. If a fact the JD
   needs isn't in the bank, that is a **gap** — see rule 4.
2. **The template is frozen.** Margins, fonts, sizes, section order, section
   labels, shading, and date alignment do not change per résumé — only which
   content is selected, reordered, or trimmed changes. If the content doesn't
   fit, use the fallback ladder in `scripts/build_resume.js` (spacing → margin
   → font size, in that order) — never hand-pick a one-off value, and never
   go outside the ladder's floors (10pt body / 0.5in margin, both from the UMN
   CLA Career Services source cited in the ladder's comments).
3. **One page, verified, every time.** "Looks like one page" is not
   verification. Render to PDF and check the page count programmatically
   (see "Build + verify loop" below) before telling Anant it's done.
4. **Ask, don't invent, when the JD needs something the bank doesn't have.**
   Stop and ask a specific, batched fact question (grouped by
   role/project, like: "For the X bullet, do you have a number for Y?").
   Never fill the gap with a plausible-sounding guess. Record anything the
   JD explicitly wants that the bank can't support as a stated gap in your
   summary to Anant — don't silently drop it.
5. **Tense and date discipline.** Ended roles/projects: past tense. Roles the
   bank marks ongoing: present tense. Never mix tenses within one role. Dates
   render as "Month YYYY – Month YYYY" (or "– Present"/whatever the bank
   currently says for an ongoing role) and are right-aligned — never reformat
   this per resume.
6. **No unsupported adjectives or scale claims.** Words like "high-performance,"
   "large-scale," "verified," "cutting-edge," "results-driven," or "passionate"
   are banned unless the bank already backs them with a specific, named
   mechanism or number. When in doubt, cut the adjective rather than keep it
   unsupported — a plain factual bullet beats an embellished one every time.
7. **ATS-safe structure, always.** Single column. No tables, text boxes,
   images, icons, or skill bars. Section labels stay exactly: EDUCATION,
   SKILLS, EXPERIENCE, PROJECTS, CERTIFICATIONS (never combine PROJECTS and
   CERTIFICATIONS back into one section — that was an explicit fix from the
   audit). Contact info lives in the document body, never in a header/footer.
   Hyperlinks keep clean, literal anchor text (never "click here" or a vague
   label like the old "Not Just a Portfolio").
8. **Selection and rephrasing only — never new claims.** Tailoring means:
   choosing which bank bullets/skills/projects are relevant to this JD,
   reordering them by relevance, and trimming for space. You may lightly
   compress a sentence that's already in the bank. You may not add a clause,
   a tool, a number, or an outcome that isn't already there.

## Inputs

- **Main Resume.md** — the evidence bank. Read the full current file before
  writing anything, every time (it gets edited between resume runs — the
  vault version is a live document, not a fixed template). If this WSL
  session can't reach the Jarvis vault directly, ask Anant to paste the
  current `Main Resume.md` content once before proceeding — don't work from
  a stale copy or from memory of an earlier run.
- **Job description** (optional). Paste, link, or file. Without one, this
  skill just rebuilds the current Main Resume unchanged (useful after the
  bank itself gets updated) — skip the JD-matching step below.
- **Company / role name**, for the output filename.

## Workflow

1. Read `Main Resume.md` in full.
2. If a JD was given: list its explicit requirements (skills, domains,
   experience type). For each one, find the matching evidence-tagged bank
   entry. For anything the JD clearly wants that has no matching entry,
   write it down as a gap — do not proceed to invent it. If a gap is
   significant (e.g. the JD's core requirement has zero bank coverage), ask
   Anant about it before finalizing rather than shipping a resume you know
   is weak on the one thing that mattered most.
3. Build `data.json` (shape: `scripts/resume_data.example.json`) by selecting,
   reordering, and lightly trimming bank content — header/education fixed,
   skills reordered to lead with JD-relevant groups, experience/projects
   reordered and pared to the most relevant items, certifications trimmed if
   space demands it before anything else is cut (it's the lowest-value
   section on the page).
4. Run the build + verify loop below.
5. Save the output to
   `20_Progress/Internship/Resumes/Altered/<Company> - <Role>.docx`
   (that `Altered/` folder already exists in the vault next to Main Resume —
   use it, don't invent a new location).
6. Report back to Anant: which bank content you used, what you cut for space
   or relevance and why, and every JD requirement you couldn't back with
   evidence (the gaps from step 2) — never a bare "done."

## Build + verify loop

```bash
# from the directory containing build_resume.js
export RESUME_FIT_STEP=0
node scripts/build_resume.js data.json "out/<Company> - <Role>.docx"
soffice --headless --convert-to pdf --outdir out "out/<Company> - <Role>.docx"
pdfinfo "out/<Company> - <Role>.pdf" | grep Pages
```

If `Pages: 1` — done, move on to step 6 of the workflow above.

If `Pages: 2+` — this is expected to happen sometimes; it is not a failure,
it's the fallback ladder doing its job:

```bash
RESUME_FIT_STEP=1 node scripts/build_resume.js data.json "out/....docx"   # tighten spacing
# re-render, re-check page count
RESUME_FIT_STEP=2 node scripts/build_resume.js data.json "out/....docx"   # margin toward 0.5in floor
# re-render, re-check
RESUME_FIT_STEP=3 node scripts/build_resume.js data.json "out/....docx"   # body font toward 10pt floor, last resort
# re-render, re-check
```

If it's still 2 pages at step 3, **stop and cut content** — pick the least
JD-relevant project or bullet and remove it from `data.json`, then restart at
`RESUME_FIT_STEP=0`. Never invent a step 4 that goes past 10pt body or 0.5in
margin; those floors come from the UMN CLA Career Services guidance
(`cla.umn.edu/career-services-office/students/excel/resume/resume-format`)
that the original audit used, and going below them is exactly the kind of
undocumented one-off fix this skill exists to prevent.

Also visually spot-check the render once (`pdftoppm -jpeg -r 130 out.pdf page
&& ` open `page-1.jpg`) before calling it done — page count alone doesn't
catch an awkward wrap or a section header sitting alone at the bottom of a
column.

## Exact frozen template settings (reference)

| Setting | Value | Why |
|---|---|---|
| Page | US Letter, 8.5×11in | Standard |
| Margins | 0.6in default (floor 0.5in — see fallback ladder) | UMN CLA Career Services: 0.5–1in |
| Font | Times New Roman throughout | UMN-cited safe font; matches Anant's existing brand |
| Name | 20pt bold, centered | UMN-cited safe range 18–22pt |
| Section headers | 11.5pt bold, `D9D9D9` shaded background | Matches verified Main Resume |
| Body text | 11pt default (floor 10pt — see fallback ladder) | UMN CLA Career Services: 10–12pt |
| Section labels | EDUCATION, SKILLS, EXPERIENCE, PROJECTS, CERTIFICATIONS — always separate, always this wording | Fixed in the 2026-08-29/30 audit; do not recombine or rename |
| Dates | Right-aligned via a right tab stop at (page width − 2×margin) | Matches verified Main Resume; UMN-cited convention |
| Bullets | `•` via a numbering definition (never a literal bullet character) | `docx` (npm) requirement |
| Hyperlinks | Literal, specific anchor text; blue + underlined | Fixed in the audit (old "Not Just a Portfolio" label was a finding) |
| Layout | Single column; zero tables, text boxes, images, icons | ATS-parseability finding from the audit |
| File metadata | `creator` = "Anant Gupta", `title` = "Anant Gupta - Resume - `<role/company>`" | Avoids leftover-template-author metadata (an audit finding on the original file) |

Full mechanics (docx-js gotchas, page-size DXA math, table/shading pitfalls)
are in the `docx` skill if this session has it; `scripts/build_resume.js`
already encodes all of it correctly, so you generally shouldn't need to touch
that skill's reference material unless `build_resume.js` needs a structural
change (e.g., a new section type Anant asks for).

## Files in this skill

- `scripts/build_resume.js` — the parameterized builder. Takes a `data.json`
  and an output path; implements the fallback ladder via `RESUME_FIT_STEP`.
  Do not change the values in `FIT_LADDER` without Anant explicitly asking —
  those are the verified/allowed settings, not defaults to tune per resume.
- `scripts/resume_data.example.json` — the current Main Resume's content in
  the exact shape `build_resume.js` expects. Use this as your starting point
  for a new `data.json`, then edit only the arrays (skills/experience/
  projects/certifications) per the JD-tailoring workflow — never touch
  `build_resume.js` itself for a routine tailoring pass.

## What "tailoring" means in practice — worked example

Say a JD is backend/infra-heavy and doesn't care about the frontend work.
Correct tailoring:
- Reorder `skills` so `Infrastructure/Data` and `AI/ML` lead, `Full-Stack/Web`
  drops to last (still included — never delete a skill group just because
  this JD doesn't emphasize it, unless space forces a cut).
- Keep the BOOM experience entry's bullets in full (strong backend/systems
  evidence); trim the NSEdu entry to its 2 strongest bullets if space is
  tight, cutting the weakest, not by inventing a "more backend" version of
  a frontend bullet.
- In Projects, lead with CausalOps and Resq (backend/systems-heavy), keep
  Orby and TradingView, drop Jarvis last if a project must be cut for space.
- Do **not** rewrite the Assisto bullet to sound more backend-focused than
  it is — it's a frontend internship bullet; either it earns its place as
  written or it gets cut, it doesn't get reinvented.

That's the whole model: **select and reorder truthfully, never reshape the
facts to fit the job.**
