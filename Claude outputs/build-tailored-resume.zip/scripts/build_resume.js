/**
 * build_resume.js — Anant Gupta resume builder (frozen template)
 *
 * Usage:
 *   node build_resume.js data.json output.docx
 *
 * data.json shape — see resume_data.example.json in this same folder.
 * Every string in data.json must already exist in Main Resume.md (the
 * evidence bank). This script does not validate that for you — the
 * skill instructions (SKILL.md, "Workflow" step 2-3) are where that
 * check happens, before this script is ever run.
 *
 * TEMPLATE VALUES BELOW ARE FROZEN. Do not hand-edit BODY_SIZE, MARGIN,
 * fonts, shading, or spacing for a single tailored resume. If a specific
 * resume won't fit one page, use the FALLBACK LADDER (see comment above
 * FIT_LADDER below) — never invent a one-off value outside that ladder.
 */
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, ExternalHyperlink,
  AlignmentType, ShadingType, Tab, TabStopType,
  LevelFormat, convertInchesToTwip,
} = require("docx");

const dataPath = process.argv[2];
const outPath = process.argv[3];
if (!dataPath || !outPath) {
  console.error("Usage: node build_resume.js data.json output.docx");
  process.exit(1);
}
const data = JSON.parse(fs.readFileSync(dataPath, "utf-8"));

// ---------------------------------------------------------------------
// FROZEN TEMPLATE — verified one-page, ATS-safe, UMN-margin-compliant.
// step = which rung of the fallback ladder we're on (0 = default/best).
// The one-page verification loop (SKILL.md) increments `step` and
// re-runs this script only if the previous step rendered to 2+ pages.
// Never skip a rung, and never go past step 3 without telling the user
// the content itself needs to be cut (that's a content problem, not a
// settings problem).
// ---------------------------------------------------------------------
const step = parseInt(process.env.RESUME_FIT_STEP || "0", 10);

const FIT_LADDER = [
  // step 0: the exact settings verified on the Main Resume (default — try this first)
  { marginIn: 0.6, bodyPt: 11, headerPt: 11.5, bulletAfter: 50, sectionAfter: 60, sectionBefore: 130 },
  // step 1: tighten spacing only — least visually invasive
  { marginIn: 0.6, bodyPt: 11, headerPt: 11.5, bulletAfter: 35, sectionAfter: 45, sectionBefore: 100 },
  // step 2: reduce margin toward (not past) the UMN-cited 0.5in floor
  { marginIn: 0.5, bodyPt: 11, headerPt: 11.5, bulletAfter: 30, sectionAfter: 40, sectionBefore: 90 },
  // step 3: reduce body font toward (not past) the UMN-cited 10pt floor — last resort
  { marginIn: 0.5, bodyPt: 10.5, headerPt: 11, bulletAfter: 25, sectionAfter: 35, sectionBefore: 80 },
];
if (step > 3) {
  console.error("Fallback ladder exhausted (step > 3). This is a content problem, not a " +
    "settings problem: cut a bullet or a project before touching fonts/margins further. " +
    "Never go below 10pt body or 0.5in margin (UMN CLA Career Services floor).");
  process.exit(2);
}
const T = FIT_LADDER[step];

const FONT = "Times New Roman";
const BODY_SIZE = Math.round(T.bodyPt * 2);     // docx wants half-points
const NAME_SIZE = 40;                            // 20pt — keep fixed; UMN-cited range is 18-22pt
const HEADER_SIZE = Math.round(T.headerPt * 2);
const SHADE = "D9D9D9";
const LINK_COLOR = "0000FF";

const MARGIN = convertInchesToTwip(T.marginIn);
const PAGE_WIDTH = convertInchesToTwip(8.5);
const PAGE_HEIGHT = convertInchesToTwip(11);
const RIGHT_TAB = PAGE_WIDTH - 2 * MARGIN;

function plain(text, opts = {}) {
  return new TextRun({ text, font: FONT, size: BODY_SIZE, ...opts });
}
function hyperlink(text, url) {
  return new ExternalHyperlink({
    link: url,
    children: [new TextRun({ text, font: FONT, size: BODY_SIZE, color: LINK_COLOR, underline: {} })],
  });
}
function sectionHeader(label) {
  return new Paragraph({
    shading: { type: ShadingType.CLEAR, color: "auto", fill: SHADE },
    spacing: { before: T.sectionBefore, after: T.sectionAfter },
    children: [new TextRun({ text: label.toUpperCase(), font: FONT, size: HEADER_SIZE, bold: true })],
  });
}
function rightAlignedLine(leftRuns, rightText, opts = {}) {
  return new Paragraph({
    tabStops: [{ type: TabStopType.RIGHT, position: RIGHT_TAB }],
    spacing: { after: 20 },
    children: [...leftRuns, new TextRun({ text: "\t" + (rightText || ""), font: FONT, size: BODY_SIZE })],
  });
}
function bullet(children) {
  return new Paragraph({ numbering: { reference: "bullet-list", level: 0 }, spacing: { after: T.bulletAfter }, children });
}
function contactLine(leftText, rightChildren) {
  return new Paragraph({
    tabStops: [{ type: TabStopType.RIGHT, position: RIGHT_TAB }],
    spacing: { after: 20 },
    children: [plain(leftText), new TextRun({ text: "\t", font: FONT, size: BODY_SIZE }), ...rightChildren],
  });
}
function skillLine(label, items) {
  return new Paragraph({
    spacing: { after: 20 },
    children: [new TextRun({ text: label + ": ", font: FONT, size: BODY_SIZE, italics: true }), plain(items.join(", "))],
  });
}
function linkRuns(links) {
  // links: [{text, url}, ...] joined with "  ·  "
  const out = [];
  links.forEach((l, i) => {
    if (i > 0) out.push(new TextRun({ text: "  ·  ", font: FONT, size: BODY_SIZE }));
    out.push(hyperlink(l.text, l.url));
  });
  return out;
}

const children = [];

// Header
children.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 50 },
  children: [new TextRun({ text: data.header.name, font: FONT, size: NAME_SIZE, bold: true })],
}));
children.push(contactLine(data.header.addressLine, linkRuns(data.header.contactLinksRow1)));
children.push(contactLine(data.header.phoneEmailLine, linkRuns(data.header.contactLinksRow2)));

// Education
children.push(sectionHeader("Education"));
data.education.forEach(e => {
  children.push(rightAlignedLine([plain(e.line, { bold: !!e.bold })], e.date));
});

// Skills
children.push(sectionHeader("Skills"));
data.skills.forEach(group => children.push(skillLine(group.label, group.items)));

// Experience
children.push(sectionHeader("Experience"));
data.experience.forEach(role => {
  children.push(rightAlignedLine([plain(role.title, { bold: true })], role.dates));
  role.bullets.forEach(b => children.push(bullet([plain(b)])));
});

// Projects
children.push(sectionHeader("Projects"));
data.projects.forEach(p => {
  children.push(bullet([
    new TextRun({ text: p.name + ": ", font: FONT, size: BODY_SIZE, bold: true }),
    plain(p.description),
  ]));
});

// Certifications
children.push(sectionHeader("Certifications"));
children.push(new Paragraph({ spacing: { after: 0 }, children: [plain(data.certifications.join("  ·  "))] }));

const doc = new Document({
  creator: data.header.name,
  title: `${data.header.name} - Resume${data.targetLabel ? " - " + data.targetLabel : ""}`,
  numbering: {
    config: [{
      reference: "bullet-list",
      levels: [{
        level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
        style: {
          paragraph: { indent: { left: convertInchesToTwip(0.2), hanging: convertInchesToTwip(0.15) } },
          run: { font: FONT, size: BODY_SIZE },
        },
      }],
    }],
  },
  sections: [{
    properties: { page: { size: { width: PAGE_WIDTH, height: PAGE_HEIGHT }, margin: { top: MARGIN, bottom: MARGIN, left: MARGIN, right: MARGIN } } },
    children,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(outPath, buf);
  console.log(`written ${outPath} (fit-ladder step ${step}: margin=${T.marginIn}in body=${T.bodyPt}pt)`);
});
